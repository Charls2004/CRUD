
import java.awt.CardLayout;
import java.awt.Component;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class STUDENT extends javax.swing.JFrame {

    /**
     * Creates new form STUDENT
     */
    Connection con;
    Statement statement;
    CardLayout cardlayout;

    public STUDENT() {
        initComponents();
        setTitle("STUDENT");    // title sa frame sa ibabaw
        cardlayout = (CardLayout) (panelCard.getLayout());
        setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    private void cardR(Component e) {
        panelCard.removeAll();
        panelCard.add(e);
        panelCard.repaint();
        panelCard.revalidate();
    }

    public void prepareConnection() {
        try {
            //connect to database
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/librarydb", "root", "");
            statement = con.createStatement();

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(adminMain.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    void borrowbook(int bookID, String booktitle, int studentID, String studentname, String issue_date) {
        prepareConnection();
        try {
            //insert data to the database name issue_book table.
            String sql = "insert into issue_book(bookID,booktitle,studentID,studentname,dateborrowed) values(?,?,?,?,?)";

            PreparedStatement prep = con.prepareStatement(sql);
            prep.setInt(1, bookID);
            prep.setString(2, booktitle);
            prep.setInt(3, studentID);
            prep.setString(4, studentname);
            prep.setString(5, issue_date);

            prep.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error in SQL\n" + e);
        }
    }

    void cardReturn() {
        prepareConnection();
        try {
            //select data from issue_book table in database and display in the JTable named return1
            String sql = "SELECT ID,bookID, booktitle, studentID, studentname, dateborrowed FROM issue_book";
            PreparedStatement statement = con.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();

            DefaultTableModel model = (DefaultTableModel) return1.getModel();
            model.setRowCount(0); // Clear existing data

            while (rs.next()) {
                Object[] row = new Object[]{
                    rs.getInt("ID"),
                    rs.getInt("bookID"),
                    rs.getString("booktitle"),
                    rs.getString("studentID"),
                    rs.getString("studentname"),
                    rs.getString("dateborrowed")

                };
                model.addRow(row);

            }

            // Close the database resources (order is important)
            rs.close();
            statement.close();
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error in SQL: " + e.getMessage());
        }
    }

    void booklist() {
        prepareConnection();
        try {
            //select the data from addbook table in databse and display the data in the JTable named booklist
            String sql = "SELECT ID, book_id, book_title, category, author_name, quantity FROM addbook";
            PreparedStatement statement = con.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();

            DefaultTableModel model = (DefaultTableModel) booklist.getModel();
            model.setRowCount(0); // Clear existing data
            
                //ibutang sa jtable ang data
            while (rs.next()) {
                Object[] row = new Object[]{
                    rs.getInt("ID"),
                    rs.getInt("book_id"),
                    rs.getString("book_title"),
                    rs.getString("author_name"),
                    rs.getString("category"),
                    rs.getInt("quantity")

                };
                model.addRow(row);

            }
            // Close the database resources (order is important)
            rs.close();
            statement.close();
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error in SQL: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel3 = new javax.swing.JPanel();
        jSplitPane1 = new javax.swing.JSplitPane();
        jPanel4 = new javax.swing.JPanel();
        Return = new javax.swing.JButton();
        borrow = new javax.swing.JButton();
        BACK = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        panelCard = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        boolist = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        booklist = new javax.swing.JTable();
        borrowbook = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        searchbook = new javax.swing.JTextField();
        search = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Book = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        searchstudent = new javax.swing.JTextField();
        Enter = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        Student = new javax.swing.JTable();
        Borrow = new javax.swing.JButton();
        returnbook = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        return1 = new javax.swing.JTable();
        return2 = new javax.swing.JButton();
        RstudentID = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        ReturnSearch = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new java.awt.Dimension(840, 560));
        setSize(new java.awt.Dimension(0, 0));
        getContentPane().setLayout(new java.awt.GridBagLayout());

        jPanel3.setBackground(new java.awt.Color(0, 102, 51));
        jPanel3.setMinimumSize(new java.awt.Dimension(600, 520));
        jPanel3.setPreferredSize(new java.awt.Dimension(600, 520));

        jSplitPane1.setBorder(null);
        jSplitPane1.setDividerSize(0);
        jSplitPane1.setEnabled(false);
        jSplitPane1.setPreferredSize(new java.awt.Dimension(500, 480));

        jPanel4.setBackground(new java.awt.Color(0, 102, 0));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jPanel4.setMinimumSize(new java.awt.Dimension(200, 478));

        Return.setText("RETURN BOOK");
        Return.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnActionPerformed(evt);
            }
        });

        borrow.setText("BORROW BOOK");
        borrow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borrowActionPerformed(evt);
            }
        });

        BACK.setText("BACK");
        BACK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BACKActionPerformed(evt);
            }
        });

        jButton1.setText("BOOK LIST");
        jButton1.setMaximumSize(new java.awt.Dimension(70, 25));
        jButton1.setMinimumSize(new java.awt.Dimension(70, 25));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addComponent(BACK, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Return, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(borrow, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 31, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(borrow, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Return, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(94, 94, 94)
                .addComponent(BACK)
                .addContainerGap(97, Short.MAX_VALUE))
        );

        jSplitPane1.setLeftComponent(jPanel4);

        panelCard.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        panelCard.setPreferredSize(new java.awt.Dimension(600, 1004));
        panelCard.setLayout(new java.awt.CardLayout());

        jPanel1.setBackground(new java.awt.Color(0, 153, 153));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI Symbol", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("WELCOME READERS!!");

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("\"Libraries store the energy that fuels the imaginations.  ");

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("They open up windows to the world and inspire us to the world and inspire us to explore");

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("and achieve, and contribute to improving our quality of life\"");

        jLabel9.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("~Sidney Sheldon");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(165, 165, 165)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jLabel7)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(144, 144, 144)
                .addComponent(jLabel8)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(250, 250, 250)
                .addComponent(jLabel9)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addGap(50, 50, 50)
                .addComponent(jLabel9)
                .addContainerGap(272, Short.MAX_VALUE))
        );

        panelCard.add(jPanel1, "card5");

        boolist.setBackground(new java.awt.Color(0, 153, 153));

        booklist.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Book ID", "Book Title", "Author", "Category", "Quantity"
            }
        ));
        jScrollPane4.setViewportView(booklist);

        javax.swing.GroupLayout boolistLayout = new javax.swing.GroupLayout(boolist);
        boolist.setLayout(boolistLayout);
        boolistLayout.setHorizontalGroup(
            boolistLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(boolistLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 614, Short.MAX_VALUE)
                .addContainerGap())
        );
        boolistLayout.setVerticalGroup(
            boolistLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(boolistLayout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 312, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(83, Short.MAX_VALUE))
        );

        panelCard.add(boolist, "card4");

        borrowbook.setBackground(new java.awt.Color(0, 153, 153));
        borrowbook.setToolTipText("");
        borrowbook.setMinimumSize(new java.awt.Dimension(0, 0));
        borrowbook.setPreferredSize(new java.awt.Dimension(0, 0));

        jLabel5.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("BORROW BOOK");

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Search Book Title: ");

        search.setText("Search");
        search.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchActionPerformed(evt);
            }
        });

        jScrollPane1.setBackground(new java.awt.Color(102, 102, 102));

        Book.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book ID.", "Book Title", "Category", "Quantity", "Author"
            }
        ));
        jScrollPane1.setViewportView(Book);

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Enter Student ID:");

        Enter.setText("Enter");
        Enter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EnterActionPerformed(evt);
            }
        });

        Student.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student ID", "Student Name"
            }
        ));
        jScrollPane2.setViewportView(Student);

        Borrow.setText("Borrow book");
        Borrow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BorrowActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout borrowbookLayout = new javax.swing.GroupLayout(borrowbook);
        borrowbook.setLayout(borrowbookLayout);
        borrowbookLayout.setHorizontalGroup(
            borrowbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(borrowbookLayout.createSequentialGroup()
                .addGroup(borrowbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(borrowbookLayout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addGroup(borrowbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(borrowbookLayout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(searchstudent, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(Enter))
                            .addGroup(borrowbookLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(borrowbookLayout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(5, 5, 5)
                                .addComponent(searchbook, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(search))))
                    .addGroup(borrowbookLayout.createSequentialGroup()
                        .addGap(220, 220, 220)
                        .addComponent(Borrow)))
                .addContainerGap(78, Short.MAX_VALUE))
        );
        borrowbookLayout.setVerticalGroup(
            borrowbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(borrowbookLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel5)
                .addGroup(borrowbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(borrowbookLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel3))
                    .addGroup(borrowbookLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(borrowbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(searchbook, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(search))))
                .addGap(7, 7, 7)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addGroup(borrowbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(borrowbookLayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(borrowbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(searchstudent, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4)))
                    .addComponent(Enter))
                .addGap(13, 13, 13)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Borrow))
        );

        panelCard.add(borrowbook, "borrowcard");

        returnbook.setBackground(new java.awt.Color(0, 153, 153));
        returnbook.setEnabled(false);
        returnbook.setPreferredSize(new java.awt.Dimension(800, 474));
        returnbook.setRequestFocusEnabled(false);
        returnbook.setVerifyInputWhenFocusTarget(false);

        jLabel6.setFont(new java.awt.Font("Verdana", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("RETURN BOOK");

        return1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Book ID", "Book Title", "Student ID", "Student Name", "Borrow Date"
            }
        ));
        jScrollPane3.setViewportView(return1);

        return2.setText("Return Book");
        return2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                return2ActionPerformed(evt);
            }
        });

        jLabel10.setText("Enter Student ID:");

        ReturnSearch.setText("Search");
        ReturnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnSearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout returnbookLayout = new javax.swing.GroupLayout(returnbook);
        returnbook.setLayout(returnbookLayout);
        returnbookLayout.setHorizontalGroup(
            returnbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(returnbookLayout.createSequentialGroup()
                .addGroup(returnbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(returnbookLayout.createSequentialGroup()
                        .addGroup(returnbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(returnbookLayout.createSequentialGroup()
                                .addGap(217, 217, 217)
                                .addComponent(jLabel6))
                            .addGroup(returnbookLayout.createSequentialGroup()
                                .addGap(261, 261, 261)
                                .addComponent(return2)))
                        .addGap(0, 262, Short.MAX_VALUE))
                    .addGroup(returnbookLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane3)))
                .addContainerGap())
            .addGroup(returnbookLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(RstudentID, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(ReturnSearch)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        returnbookLayout.setVerticalGroup(
            returnbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(returnbookLayout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addComponent(jLabel6)
                .addGap(16, 16, 16)
                .addGroup(returnbookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(RstudentID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(ReturnSearch))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(return2)
                .addContainerGap(90, Short.MAX_VALUE))
        );

        panelCard.add(returnbook, "returncard");

        jSplitPane1.setRightComponent(panelCard);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(jSplitPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 842, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jSplitPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 264;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(0, 150, 0, 12);
        getContentPane().add(jPanel3, gridBagConstraints);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void borrowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_borrowActionPerformed
        // TODO add your handling code here:
        cardR(borrowbook);

    }//GEN-LAST:event_borrowActionPerformed

    private void ReturnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnActionPerformed
        // TODO add your handling code here:

        cardR(returnbook);
        cardReturn();
    }//GEN-LAST:event_ReturnActionPerformed

    private void BACKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BACKActionPerformed
        // TODO add your handling code here:
        new main1().setVisible(true);
        this.dispose();

    }//GEN-LAST:event_BACKActionPerformed

    private void searchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchActionPerformed

        //search the book title in order to borrow
        String txt = searchbook.getText();
        if (txt.length() == 0) {
            JOptionPane.showMessageDialog(this, "Please fill in the details", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        prepareConnection();

        try {
            // Execute a SQL query to search for books with titles containing the search text
            String sql = "SELECT * FROM addbook WHERE book_title = \'" + txt + "\'";
            ResultSet rs = statement.executeQuery(sql);

            // Clear the previous book data
            DefaultTableModel model = (DefaultTableModel) Book.getModel();
            model.setRowCount(0);

            // Add the new book data to the table
            while (rs.next()) {
                Object[] row = {rs.getInt("book_id"), rs.getString("book_title"), rs.getString("category"), rs.getInt("quantity"), rs.getString("author_name")};
                model.addRow(row);
            }

            // Close the database resources
            rs.close();
            statement.close();
            con.close();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error in SQL" + ex);
        }
    }//GEN-LAST:event_searchActionPerformed

    private void EnterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EnterActionPerformed

        //search the Student ID in order to borrow the book
        String txt = searchstudent.getText();
        if (txt.length() == 0) {
            JOptionPane.showMessageDialog(this, "Please fill in the details", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        prepareConnection();
        try {
            // Execute a SQL query to search for student with studentID containing the search text
            String sql = "SELECT * FROM student WHERE studentID = \'" + txt + "\'";
            ResultSet rs = statement.executeQuery(sql);

            // Clear the previous book data
            DefaultTableModel model = (DefaultTableModel) Student.getModel();
            model.setRowCount(0);

            // Add the new book data to the table
            while (rs.next()) {
                Object[] row = {rs.getInt("studentID"), rs.getString("studentname")};
                model.addRow(row);
            }

            // Close the database resources
            rs.close();
            statement.close();
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error in SQL" + ex);
        }


    }//GEN-LAST:event_EnterActionPerformed

    private void BorrowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BorrowActionPerformed

        int idxBook = Book.getSelectedRow();
        int idxStudent = Student.getSelectedRow();

        if (idxBook == -1 || idxStudent == -1) {
            JOptionPane.showMessageDialog(this, "Please select book and student from the table", "Invalid Operation", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int studentid = (int) Student.getModel().getValueAt(idxStudent, 0);    //studentID
        String name = (String) Student.getModel().getValueAt(idxStudent, 1); //studentname
        int bookid = (int) Book.getModel().getValueAt(idxBook, 0);   //bookID
        String bookname = (String) Book.getModel().getValueAt(idxBook, 1);   //booktitle

        int count = Integer.parseInt("" + Book.getModel().getValueAt(idxBook, 3));  //Quantity

        //date on when the book is borrowed
        Calendar cal = Calendar.getInstance();
        Date curDate = cal.getTime();
        Date issue_date = curDate;
        Date return_date = cal.getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM_dd");
        String formattedDate = formatter.format(curDate);

        if (count <= 0) {
            JOptionPane.showMessageDialog(this, "Book not available", "Unavailable", JOptionPane.ERROR_MESSAGE);
            return;
        } else {

//             // the borrowbook is from the top it will perform the action in the top named void borrowbook 
//             //in order to insert the book to issue_book table database.
//             borrowbook( bookid,isbn, usn, name, formattedDate);
            try {
                prepareConnection();
                String query1 = "SELECT * FROM issue_book WHERE studentID = ?";
                PreparedStatement statement1 = con.prepareStatement(query1);
                statement1.setInt(1, studentid);
                ResultSet resultSet = statement1.executeQuery();

                //perform if you still have a book that not yet returned
                if (resultSet.next()) {

                    StringBuilder notReturnedBooks = new StringBuilder();

                    do {
                        //get the value from issue_book in DB
                        int bookID = resultSet.getInt("bookID");
                        String booktitle = resultSet.getString("booktitle");
                        Date dateborrowed = resultSet.getDate("dateborrowed");
                        int studentID = resultSet.getInt("studentID");

                        notReturnedBooks.append("Student ID: " + studentID + "\nBook ID: " + bookID + "\nTitle: " + booktitle + "\nDate Borrowed: " + dateborrowed + "\n");
                    } while (resultSet.next());
                    JOptionPane.showMessageDialog(this, "You still have the following books to return:\n" + notReturnedBooks.toString() + "\n", "Books Not Returned", JOptionPane.INFORMATION_MESSAGE);
                }

                // the borrowbook is from the top it's a class and it  will perform the action in the top named void borrowbook 
                //in order to insert the book to issue_book table database.
                borrowbook(bookid, bookname, studentid, name, formattedDate);

                //decrement the quantity of the book
                String query = "UPDATE addbook SET quantity = quantity - 1 WHERE book_id = ?";
                PreparedStatement statement = con.prepareStatement(query);
                statement.setInt(1, bookid);
                statement.executeUpdate();

                searchActionPerformed(evt);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error in sql " + e);
            }

            JOptionPane.showMessageDialog(this, "Borrow Book succefully \nBook borrow date: " + formattedDate);

        }

    }//GEN-LAST:event_BorrowActionPerformed

    private void return2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_return2ActionPerformed
        // TODO add your handling code here:
        prepareConnection();
        //select data from issue_book and display in the JTable name booklist.
        try {
            String sql = "SELECT ID, bookID, booktitle, studentID, studentname, dateborrowed FROM issue_book";
            PreparedStatement statement = con.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();

            DefaultTableModel model = (DefaultTableModel) booklist.getModel();
            model.setRowCount(0); // Clear existing data

            while (rs.next()) {
                Object[] row = new Object[]{
                    rs.getInt(1),
                    rs.getInt(2),
                    rs.getString(3),
                    rs.getString(4),
                    rs.getString(5),
                    rs.getString(6)

                };

                model.addRow(row);

            }

            // Close the database resources (order is important)
            rs.close();
            statement.close();
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error in SQL: " + e.getMessage());
        }

        //when the button return is click the data will be remove from issue_book and be stored in the history
        int tablereturn = return1.getSelectedRow();

        if (tablereturn == -1) {
            JOptionPane.showMessageDialog(this, "Please select book from the table", "Invalid Operation", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String name = (String) return1.getModel().getValueAt(tablereturn, 4); //studentname
        int bookid = (int) return1.getModel().getValueAt(tablereturn, 1);   //bookID
        String isbn = (String) return1.getModel().getValueAt(tablereturn, 2);   //booktitle
        int studentid = Integer.parseInt("" + return1.getModel().getValueAt(tablereturn, 3));    //studentID

        String borroweddate = (String) return1.getModel().getValueAt(tablereturn, 5);      //borroweddate

        //date
        Calendar cal = Calendar.getInstance();
        Date curDate = cal.getTime();
        Date issue_date = curDate;
        Date return_date = cal.getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = formatter.format(curDate);

        try {
            prepareConnection();
            String sql = "INSERT INTO history( bookID, booktitle, studentID, studentname, dateborrowed, datereturn) VALUES (?,?,?,?,?,?)";

            PreparedStatement prep = con.prepareStatement(sql);

            prep.setInt(1, bookid);
            prep.setString(2, isbn);
            prep.setInt(3, studentid);
            prep.setString(4, name);
            prep.setString(5, borroweddate);
            prep.setString(6, formattedDate);

            prep.executeUpdate();
            JOptionPane.showMessageDialog(this, "Return Book succefully \nBook borrow date: " + formattedDate);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error in SQL " + ex);
        }

        //remove from list
        DefaultTableModel table = (DefaultTableModel) return1.getModel();
        prepareConnection();
        String id = "";
        int row = -1;
        int select = return1.getSelectedRow();

        try {
            row = return1.getSelectedRow();
            id = "" + return1.getValueAt(row, 0);
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(this, "No Book Selected");
            return;
        } catch (ArrayIndexOutOfBoundsException ex) {
            JOptionPane.showMessageDialog(this, "No Book Selected");
            return;
        } catch (NoSuchMethodError ex) {
            JOptionPane.showMessageDialog(this, "No Book Selected");
            return;
        }

        try {
            //delete the data in issue_book table in database
            String query = "DELETE FROM issue_book WHERE ID= ?";
            PreparedStatement prep = con.prepareStatement(query);
            prep.setString(1, id);
            prep.executeUpdate();
            table.removeRow(row);

        } catch (SQLException ex) {
            Logger.getLogger(adminMain.class.getName()).log(Level.SEVERE, null, ex);
        }

        try {

            // Increment quantity in addbook table
            String query = "UPDATE addbook SET quantity = quantity + 1 WHERE book_id = ?";
            PreparedStatement statement = con.prepareStatement(query);
            statement.setInt(1, bookid);
            statement.executeUpdate();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error in SQL: " + e.getMessage());
        }


    }//GEN-LAST:event_return2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        cardR(boolist);
        booklist();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void ReturnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnSearchActionPerformed
        // TODO add your handling code here:
        //search the Student ID in order to borrow the book
        String txt = RstudentID.getText();
        if (txt.length() == 0) {
            JOptionPane.showMessageDialog(this, "Please fill in the details", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        prepareConnection();
        try {
            // Execute a SQL query to search for student with studentID containing the search text
            String sql = "SELECT * FROM issue_book WHERE studentID = \'" + txt + "\'";
            ResultSet rs = statement.executeQuery(sql);

            // Clear the previous book data
            DefaultTableModel model = (DefaultTableModel) return1.getModel();
            model.setRowCount(0);

            // Add the new book data to the table
            while (rs.next()) {
                Object[] row = new Object[]{
                    rs.getInt("ID"),
                    rs.getInt("bookID"),
                    rs.getString("booktitle"),
                    rs.getString("studentID"),
                    rs.getString("studentname"),
                    rs.getString("dateborrowed")

                };
                model.addRow(row);

            }

            // Close the database resources
            rs.close();
            statement.close();
            con.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error in SQL" + ex);
        }


    }//GEN-LAST:event_ReturnSearchActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(STUDENT.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(STUDENT.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(STUDENT.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(STUDENT.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new STUDENT().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BACK;
    private javax.swing.JTable Book;
    private javax.swing.JButton Borrow;
    private javax.swing.JButton Enter;
    private javax.swing.JButton Return;
    private javax.swing.JButton ReturnSearch;
    private javax.swing.JTextField RstudentID;
    private javax.swing.JTable Student;
    private javax.swing.JTable booklist;
    private javax.swing.JPanel boolist;
    private javax.swing.JButton borrow;
    private javax.swing.JPanel borrowbook;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JPanel panelCard;
    private javax.swing.JTable return1;
    private javax.swing.JButton return2;
    private javax.swing.JPanel returnbook;
    private javax.swing.JButton search;
    private javax.swing.JTextField searchbook;
    private javax.swing.JTextField searchstudent;
    // End of variables declaration//GEN-END:variables
}
