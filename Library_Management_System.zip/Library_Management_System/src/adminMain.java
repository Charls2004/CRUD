
import java.awt.CardLayout;
import java.awt.Component;
import javax.swing.JFrame;
import java.sql.DriverManager;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;
import java.sql.Statement;

public class adminMain extends javax.swing.JFrame {

    /**
     * Creates new form ADMINMAIN
     */
    Connection con;
    Statement statement;
    CardLayout cardlayout;

    public adminMain() {
        initComponents();
        setTitle("ADMIN");
        cardlayout = (CardLayout) (panelCard.getLayout());
        //full screen
        setExtendedState(JFrame.MAXIMIZED_BOTH);

    }

    private void cardR(Component e) {
        panelCard.removeAll();
        panelCard.add(e);
        panelCard.repaint();
        panelCard.revalidate();
    }

    public void prepareConnection() {
        try {
            //connect to the database
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/librarydb", "root", "");
            statement = con.createStatement();

        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(adminMain.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    void addBook(int book_id, String title, String category, String author, int quantity) {
        prepareConnection();
        try {
            //insert all the data written and choose in Textfield and in combo box
            String sql = "insert into addbook(book_ID,book_title,category, author_name,quantity ) values(?,?,?,?,?)";

            PreparedStatement prep = con.prepareStatement(sql);
            prep.setInt(1, book_id);
            prep.setString(2, title);
            prep.setString(3, category);
            prep.setString(4, author);
            prep.setInt(5, quantity);

            prep.executeUpdate();
            JOptionPane.showMessageDialog(this, "Data inserted successfully");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error in SQL\n" + e);
        }
    }

    void addStudent(int studentid, String studentname) {
        prepareConnection();

        try {
            // Check if studentID already exists name
            String sqlCheckStudentID = "SELECT COUNT(*) FROM student WHERE studentID = ?";
            PreparedStatement checkStudentID = con.prepareStatement(sqlCheckStudentID);
            checkStudentID.setInt(1, studentid);
            ResultSet rs = checkStudentID.executeQuery();
            rs.next();
            int countStudentID = rs.getInt(1);

            // Check if studentname already exists ID
            String sqlCheckStudentName = "SELECT COUNT(*) FROM student WHERE studentname = ?";
            PreparedStatement checkStudentName = con.prepareStatement(sqlCheckStudentName);
            checkStudentName.setString(1, studentname);
            rs = checkStudentName.executeQuery();
            rs.next();
            int countStudentName = rs.getInt(1);

            //if the student is already exist in the database
            if (countStudentID > 0 || countStudentName > 0) {
                JOptionPane.showMessageDialog(this, "Student already exists");
                return; 
            } else {
                // Insert Student if the student does not yet exisit in the database
                String sqlInsert = "insert into student (studentID, studentname) values(?,?)";

                PreparedStatement prep = con.prepareStatement(sqlInsert);
                prep.setInt(1, studentid);
                prep.setString(2, studentname);

                prep.executeUpdate();
                JOptionPane.showMessageDialog(this, "Student added successfully");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error in SQL\n" + ex);
        }
    }

    void borrowbook() {
        prepareConnection();
        try {
            String sql = "SELECT ID, bookID, booktitle, studentID, studentname, dateborrowed FROM issue_book";
            PreparedStatement statement = con.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();

            DefaultTableModel model = (DefaultTableModel) issue.getModel();
            model.setRowCount(0); // Clear existing data

            while (rs.next()) {
                Object[] row = new Object[]{
                    rs.getInt("ID"),
                    rs.getInt("bookID"),
                    rs.getString("booktitle"),
                    rs.getInt("studentID"),
                    rs.getString("studentname"),
                    rs.getDate("dateborrowed")
                };
                model.addRow(row);
            }

            // Close the database resources (order is important)
            rs.close();
            statement.close();
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error in SQL: " + e.getMessage());
        }
    }

    void booklist() {
        prepareConnection();
        try {
            String sql = "SELECT ID, book_id, book_title, category, author_name, quantity FROM addbook";
            PreparedStatement statement = con.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();

            DefaultTableModel model = (DefaultTableModel) booklist.getModel();
            model.setRowCount(0); // Clear existing data

            while (rs.next()) {
                Object[] row = new Object[]{
                    rs.getInt("ID"),
                    rs.getInt("book_id"),
                    rs.getString("book_title"),
                    rs.getString("author_name"),
                    rs.getString("category"),
                    rs.getInt("quantity")

                };
                model.addRow(row);

            }

            // Close the database resources (order is important)
            rs.close();
            statement.close();
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error in SQL: " + e.getMessage());
        }
    }

    void history() {
        prepareConnection();
        try {
            String sql = "SELECT ID, bookID, booktitle, studentID, studentname, dateborrowed, datereturn FROM history";
            PreparedStatement statement = con.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();

            DefaultTableModel model = (DefaultTableModel) return1.getModel();
            model.setRowCount(0); // Clear existing data

            while (rs.next()) {
                Object[] row = new Object[]{
                    rs.getInt("ID"),
                    rs.getInt("bookID"),
                    rs.getString("booktitle"),
                    rs.getString("studentID"),
                    rs.getString("studentname"),
                    rs.getString("dateborrowed"),
                    rs.getString("datereturn")

                };
                model.addRow(row);

            }

            // Close the database resources (order is important)
            rs.close();
            statement.close();
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error in SQL: " + e.getMessage());
        }
    }

    void studentlist() {

        prepareConnection();
        try {
            String sql = "SELECT studentID, studentname FROM student";
            PreparedStatement statement = con.prepareStatement(sql);
            ResultSet rs = statement.executeQuery();

            DefaultTableModel model = (DefaultTableModel) stulist.getModel();
            model.setRowCount(0); // Clear existing data

            while (rs.next()) {
                Object[] row = new Object[]{
                    rs.getInt("studentID"),
                    rs.getString("studentname")

                };
                model.addRow(row);

            }

            // Close the database resources (order is important)
            rs.close();
            statement.close();
            con.close();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error in SQL: " + e);
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel13 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jSplitPane1 = new javax.swing.JSplitPane();
        jPanel1 = new javax.swing.JPanel();
        addbook = new javax.swing.JButton();
        addstudent = new javax.swing.JButton();
        issuedbook = new javax.swing.JButton();
        listallbooks = new javax.swing.JButton();
        logout = new javax.swing.JButton();
        history = new javax.swing.JButton();
        studentlist = new javax.swing.JButton();
        panelCard = new javax.swing.JPanel();
        Addbook = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        bookID = new javax.swing.JTextField();
        bookTitle = new javax.swing.JTextField();
        authorName = new javax.swing.JTextField();
        quantity = new javax.swing.JTextField();
        save = new javax.swing.JButton();
        category = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        Addstudent = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        studentid = new javax.swing.JTextField();
        studentname = new javax.swing.JTextField();
        add = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        borrowedBook = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        issue = new javax.swing.JTable();
        Listallbooks = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        booklist = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        upcategory = new javax.swing.JComboBox<>();
        upbookid = new javax.swing.JTextField();
        upbooktitle = new javax.swing.JTextField();
        upauthor = new javax.swing.JTextField();
        upquantity = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        idlabel = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        update = new javax.swing.JButton();
        delete = new javax.swing.JButton();
        liststudent = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        stulist = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        History = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        return1 = new javax.swing.JTable();
        jLabel23 = new javax.swing.JLabel();
        deletehistory = new javax.swing.JButton();

        jLabel13.setText("jLabel13");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setIconImages(null);
        setMinimumSize(new java.awt.Dimension(500, 500));
        setSize(new java.awt.Dimension(503, 200));
        getContentPane().setLayout(new java.awt.GridBagLayout());

        jPanel2.setBackground(new java.awt.Color(0, 102, 0));

        jSplitPane1.setBorder(null);
        jSplitPane1.setDividerSize(0);

        jPanel1.setBackground(new java.awt.Color(51, 102, 0));
        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        addbook.setText("ADD BOOK");
        addbook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addbookActionPerformed(evt);
            }
        });

        addstudent.setText("ADD STUDENT");
        addstudent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addstudentActionPerformed(evt);
            }
        });

        issuedbook.setText("BORROWED BOOK");
        issuedbook.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                issuedbookActionPerformed(evt);
            }
        });

        listallbooks.setText("LIST ALL BOOKS");
        listallbooks.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listallbooksActionPerformed(evt);
            }
        });

        logout.setText("Log out");
        logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logoutActionPerformed(evt);
            }
        });

        history.setText("HISTORY");
        history.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                historyActionPerformed(evt);
            }
        });

        studentlist.setText("LIST ALL STUDENT");
        studentlist.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentlistActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(logout)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(addbook, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(listallbooks, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(issuedbook, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(addstudent, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(history, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(studentlist, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(addbook, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(addstudent, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(issuedbook, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(listallbooks, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(studentlist, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addComponent(history, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(logout)
                .addGap(7, 7, 7))
        );

        jSplitPane1.setLeftComponent(jPanel1);

        panelCard.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        panelCard.setLayout(new java.awt.CardLayout());

        Addbook.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("ADD BOOK");
        jLabel2.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        Addbook.add(jLabel2);
        jLabel2.setBounds(280, 20, 140, 33);

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Book ID");
        Addbook.add(jLabel3);
        jLabel3.setBounds(200, 80, 59, 19);

        jLabel4.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Book Title");
        Addbook.add(jLabel4);
        jLabel4.setBounds(200, 120, 75, 19);

        jLabel5.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Category");
        Addbook.add(jLabel5);
        jLabel5.setBounds(200, 180, 67, 19);

        jLabel6.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Author Name");
        Addbook.add(jLabel6);
        jLabel6.setBounds(200, 220, 98, 19);

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Quantity");
        Addbook.add(jLabel7);
        jLabel7.setBounds(200, 260, 65, 19);

        bookID.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        bookID.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        Addbook.add(bookID);
        bookID.setBounds(340, 80, 183, 20);

        bookTitle.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        bookTitle.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        Addbook.add(bookTitle);
        bookTitle.setBounds(340, 120, 180, 20);

        authorName.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        authorName.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        Addbook.add(authorName);
        authorName.setBounds(340, 220, 188, 20);

        quantity.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        quantity.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        Addbook.add(quantity);
        quantity.setBounds(340, 260, 188, 20);

        save.setText("Add Book");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });
        Addbook.add(save);
        save.setBounds(380, 320, 100, 25);

        category.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Fantasy", "Science Fiction", "Horror", "Romance", "Adventure", "History" }));
        category.setSelectedItem("");
        Addbook.add(category);
        category.setBounds(340, 180, 180, 22);

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bg.jpg"))); // NOI18N
        Addbook.add(jLabel8);
        jLabel8.setBounds(0, 0, 840, 480);

        panelCard.add(Addbook, "card3");

        Addstudent.setLayout(null);

        jLabel9.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("ADD STUDENT");
        Addstudent.add(jLabel9);
        jLabel9.setBounds(280, 20, 160, 60);

        jPanel3.setBackground(new java.awt.Color(139, 130, 77));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        jPanel3.setLayout(null);

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Student ID");
        jPanel3.add(jLabel10);
        jLabel10.setBounds(14, 54, 60, 16);

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Student Name");
        jPanel3.add(jLabel11);
        jLabel11.setBounds(14, 126, 80, 16);

        studentid.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.add(studentid);
        studentid.setBounds(108, 51, 148, 20);

        studentname.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.add(studentname);
        studentname.setBounds(108, 123, 148, 20);

        add.setBackground(new java.awt.Color(153, 153, 153));
        add.setText("Add Student");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });
        jPanel3.add(add);
        add.setBounds(120, 220, 99, 25);

        Addstudent.add(jPanel3);
        jPanel3.setBounds(220, 100, 320, 300);

        jLabel12.setBackground(new java.awt.Color(212, 244, 236));
        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bg.jpg"))); // NOI18N
        Addstudent.add(jLabel12);
        jLabel12.setBounds(0, 0, 800, 480);

        panelCard.add(Addstudent, "card4");

        borrowedBook.setBackground(new java.awt.Color(0, 153, 0));

        jLabel14.setText("LIST OF BOOKS BORROWED");

        issue.setBackground(new java.awt.Color(222, 255, 244));
        issue.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Book ID", "Book Title", "Student ID", "Student Name", "Date Borrowed"
            }
        ));
        jScrollPane1.setViewportView(issue);

        javax.swing.GroupLayout borrowedBookLayout = new javax.swing.GroupLayout(borrowedBook);
        borrowedBook.setLayout(borrowedBookLayout);
        borrowedBookLayout.setHorizontalGroup(
            borrowedBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(borrowedBookLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 768, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(borrowedBookLayout.createSequentialGroup()
                .addGap(311, 311, 311)
                .addComponent(jLabel14)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        borrowedBookLayout.setVerticalGroup(
            borrowedBookLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(borrowedBookLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(jLabel14)
                .addGap(36, 36, 36)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(70, Short.MAX_VALUE))
        );

        panelCard.add(borrowedBook, "card5");

        Listallbooks.setBackground(new java.awt.Color(51, 102, 0));

        jLabel15.setFont(new java.awt.Font("Sitka Text", 3, 24)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("LIST OF BOOKS");

        booklist.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Book ID", "Book Name", "Author", "Category", "Quantity"
            }
        ));
        booklist.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                booklistMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(booklist);

        jPanel4.setBackground(new java.awt.Color(61, 117, 117));
        jPanel4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("Book ID:");

        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Book Title");

        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Category");

        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Quantity");

        jLabel21.setText("Author");

        upcategory.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Fantasy", "Science Fiction", "Horror", "Romance", "Adventure", "History" }));
        upcategory.setSelectedItem("");

        jLabel22.setBackground(new java.awt.Color(76, 114, 0));
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel22.setText("UPDATE BOOKS");

        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("ID");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(idlabel, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel17)
                        .addComponent(jLabel18)
                        .addComponent(jLabel21)))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(upauthor, javax.swing.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE)
                            .addComponent(upbookid)
                            .addComponent(upbooktitle))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel20)
                                .addGap(27, 27, 27)
                                .addComponent(upquantity))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(jLabel19)
                                .addGap(24, 24, 24)
                                .addComponent(upcategory, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(141, 141, 141))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(73, 73, 73)
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel16, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                            .addComponent(idlabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(23, 23, 23)))
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel19)
                            .addComponent(upcategory, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(35, 35, 35)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel20)
                            .addComponent(upquantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel17)
                            .addComponent(upbookid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(35, 35, 35)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel18)
                            .addComponent(upbooktitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(35, 35, 35)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(upauthor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jPanel5.setBackground(new java.awt.Color(71, 117, 117));
        jPanel5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        update.setText("UPDATE");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        delete.setText("DELETE");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(delete, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(delete, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );

        javax.swing.GroupLayout ListallbooksLayout = new javax.swing.GroupLayout(Listallbooks);
        Listallbooks.setLayout(ListallbooksLayout);
        ListallbooksLayout.setHorizontalGroup(
            ListallbooksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ListallbooksLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(ListallbooksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 768, Short.MAX_VALUE)
                    .addGroup(ListallbooksLayout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, ListallbooksLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel15)
                .addGap(299, 299, 299))
        );
        ListallbooksLayout.setVerticalGroup(
            ListallbooksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ListallbooksLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel15)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(ListallbooksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelCard.add(Listallbooks, "card6");

        liststudent.setBackground(new java.awt.Color(0, 153, 0));
        liststudent.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel24.setFont(new java.awt.Font("SimSun", 1, 36)); // NOI18N
        jLabel24.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel24.setText("STUDENT LISTS");
        liststudent.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(245, 13, 296, 48));

        stulist.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student ID", "Student Name"
            }
        ));
        jScrollPane4.setViewportView(stulist);

        liststudent.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 68, -1, 318));

        jButton1.setText("DELETE");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        liststudent.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(334, 414, 167, 39));

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/bg.jpg"))); // NOI18N
        liststudent.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 500));

        panelCard.add(liststudent, "card7");

        History.setBackground(new java.awt.Color(0, 153, 0));

        return1.setBackground(new java.awt.Color(205, 255, 242));
        return1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Book ID", "Book Title", "Student ID", "Student Name", "Date Borrowed", "Date Return"
            }
        ));
        jScrollPane3.setViewportView(return1);

        jLabel23.setBackground(new java.awt.Color(51, 153, 0));
        jLabel23.setFont(new java.awt.Font("Segoe UI Semibold", 1, 24)); // NOI18N
        jLabel23.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel23.setText("HISTORY");

        deletehistory.setText("DELETE ");
        deletehistory.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletehistoryActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout HistoryLayout = new javax.swing.GroupLayout(History);
        History.setLayout(HistoryLayout);
        HistoryLayout.setHorizontalGroup(
            HistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HistoryLayout.createSequentialGroup()
                .addGroup(HistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(HistoryLayout.createSequentialGroup()
                        .addGap(250, 250, 250)
                        .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(HistoryLayout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 742, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(HistoryLayout.createSequentialGroup()
                        .addGap(296, 296, 296)
                        .addComponent(deletehistory, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        HistoryLayout.setVerticalGroup(
            HistoryLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HistoryLayout.createSequentialGroup()
                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(deletehistory, javax.swing.GroupLayout.DEFAULT_SIZE, 33, Short.MAX_VALUE)
                .addContainerGap())
        );

        panelCard.add(History, "card6");

        jSplitPane1.setRightComponent(panelCard);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jSplitPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 957, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jSplitPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 486, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel2, new java.awt.GridBagConstraints());

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void addbookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addbookActionPerformed
        // TODO add your handling code here:
        cardR(Addbook);
    }//GEN-LAST:event_addbookActionPerformed

    private void addstudentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addstudentActionPerformed
        // TODO add your handling code here:
        cardR(Addstudent);
    }//GEN-LAST:event_addstudentActionPerformed

    private void issuedbookActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_issuedbookActionPerformed
        // TODO add your handling code here:
        cardR(borrowedBook);
        borrowbook();

    }//GEN-LAST:event_issuedbookActionPerformed

    private void listallbooksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listallbooksActionPerformed
        // TODO add your handling code here:
        cardR(Listallbooks);
        booklist();

    }//GEN-LAST:event_listallbooksActionPerformed

    private void logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logoutActionPerformed
        // TODO add your handling code here:
        new main1().setVisible(true);
        this.dispose();

    }//GEN-LAST:event_logoutActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
// this is the button save on adding a new book

//getting the text written in  the textfield and the coose in combo boxes
        int book_id = Integer.parseInt(bookID.getText());
        String book_title = bookTitle.getText();
        String categoryx = (String) category.getSelectedItem();
        String author = authorName.getText();

        int qua = Integer.parseInt(quantity.getText());

        if (bookID.equals("") || book_title.equals("") || category.equals("") || authorName.equals("") || quantity.equals("")) {
            JOptionPane.showMessageDialog(this, "Fields can't be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        } else {

            //perform the addbook class which is located at the top
            addBook(book_id, book_title, categoryx, author, qua);
            bookID.setText("");
            bookTitle.setText("");
            category.setSelectedItem("");
            authorName.setText("");
            quantity.setText("");

        }

    }//GEN-LAST:event_saveActionPerformed

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        // TODO add your handling code here:

        //this the button to add the new student
        //get the text written in the textfield
        int student_id = Integer.parseInt(studentid.getText());
        String name = studentname.getText();

        if (studentid.equals("") || studentname.equals("")) {
            JOptionPane.showMessageDialog(this, "Fields can't be empty", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        } else {
            //perform the addstudent class which is in the top
            addStudent(student_id, name);
            studentid.setText("");
            studentname.setText("");
        }

    }//GEN-LAST:event_addActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        //set the booklist as the main table
        DefaultTableModel table = (DefaultTableModel) booklist.getModel();
        prepareConnection();
        String id = "";
        int row = -1;
        int select = booklist.getSelectedRow();

        try {
            row = booklist.getSelectedRow();
            id = "" + booklist.getValueAt(row, 0);
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(this, "No Book Selected");
            return;
        } catch (ArrayIndexOutOfBoundsException ex) {
            JOptionPane.showMessageDialog(this, "No Book Selected");
            return;
        } catch (NoSuchMethodError ex) {
            JOptionPane.showMessageDialog(this, "No Book Selected");
            return;
            //we put return so the code will not continue to the next try catch witch is the next of this part be perfomed
        }

        try {

            String query = "DELETE FROM addbook WHERE ID= ?";
            PreparedStatement prep = con.prepareStatement(query);
            prep.setString(1, id);
            prep.executeUpdate();   //execute the update we made which is delete also delete the data in addbook
            JOptionPane.showMessageDialog(this, "Delete Succesfully");
            table.removeRow(row);   //perform the removerow, means it will be remove also on the jtable

            idlabel.setText("");
            upbookid.setText("");
            upbooktitle.setText("");
            upauthor.setText("");
            upcategory.setSelectedItem(1);
            upquantity.setText("");

        } catch (SQLException ex) {
            Logger.getLogger(adminMain.class.getName()).log(Level.SEVERE, null, ex);
        }


    }//GEN-LAST:event_deleteActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed

        prepareConnection();

        //we get what is written in textfield
        String id = idlabel.getText();
        String book_id = upbookid.getText();
        String book_title = upbooktitle.getText();
        String categoryx = (String) upcategory.getSelectedItem();
        String author = upauthor.getText();
        String qua = upquantity.getText();

        if (book_id.isEmpty() || book_title.isEmpty() || categoryx.equals("") || author.isEmpty() || qua.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please Select Book", "Error", JOptionPane.ERROR_MESSAGE);
            return;

        } else {

            try {
                //perform the update and update the data in database from the data we get
                String sql = "UPDATE `addbook` SET `book_id`='" + book_id + "',`book_title`='" + book_title + "',`category`='" + categoryx + "',`author_name`='" + author + "',`quantity`='" + qua + "' WHERE ID ='" + id + "'";
                statement.executeUpdate(sql);
                upbookid.setText("");
                upbooktitle.setText("");
                upcategory.setSelectedItem(1);
                upauthor.setText("");
                upquantity.setText("");
                booklist();  //refresh and table
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, ex);
            }
        }

    }//GEN-LAST:event_updateActionPerformed

    private void booklistMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_booklistMouseClicked
        // TODO add your handling code here:
        prepareConnection();

        int row = booklist.getSelectedRow();

        if (row > -1) { // check if a row is selected
            Object value = booklist.getValueAt(row, 0);
            Object value0 = booklist.getValueAt(row, 1); // retrieve the value at the selected row and first column
            Object value1 = booklist.getValueAt(row, 2);
            Object value2 = booklist.getValueAt(row, 3);
            Object value3 = booklist.getValueAt(row, 4);
            Object value4 = booklist.getValueAt(row, 5);

            if (value != null) {
                String ID = value.toString();
                idlabel.setText(ID);

            }

            if (value0 != null) { // check if the value is not null
                String text = value0.toString(); // convert the value to a string
                upbookid.setText(text); // set the text of the text field

            }

            if (value1 != null) { // check if the value is not null
                String text = value1.toString(); // convert the value to a string
                upbooktitle.setText(text); // set the text of the text field

            }

            if (value2 != null) { // check if the value is not null
                String text = value2.toString(); // convert the value to a string
                upauthor.setText(text); // set the text of the text field

            }

            if (value3 != null) { // check if the value is not null
                String text = value3.toString(); // convert the value to a string
                upcategory.setSelectedItem(text); // set the selected index of the combo box
                //upcategory.setSelectedItem("text");            
            }

            if (value4 != null) { // check if the value is not null
                String text = value4.toString(); // convert the value to a string
                upquantity.setText(text); // set the text of the text field

            }

        }

    }//GEN-LAST:event_booklistMouseClicked

    private void historyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_historyActionPerformed
        // TODO add your handling code here:
        cardR(History);
        history();

        //the cardR is to change the frame and change it in History jframe
        //the history(); --- it is a class from the top it will perform what is the function given in the history class
    }//GEN-LAST:event_historyActionPerformed

    private void deletehistoryActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletehistoryActionPerformed
        // TODO add your handling code here:

        //set the booklist as the main table
        DefaultTableModel table = (DefaultTableModel) return1.getModel();
        prepareConnection();

        String id = "";
        int row = -1;

        int select = return1.getSelectedRow();

        try {
            row = return1.getSelectedRow();
            id = "" + return1.getValueAt(row, 0);
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(this, "No Book Selected");
            return;
        } catch (ArrayIndexOutOfBoundsException ex) {
            JOptionPane.showMessageDialog(this, "No Book Selected");
            return;
        } catch (NoSuchMethodError ex) {
            JOptionPane.showMessageDialog(this, "No Book Selected");
            return;
            //we put return so the code will not continue to the next try catch witch is the next of this part be perfomed
        }

        try {

            String query = "DELETE FROM history WHERE ID= ?";
            PreparedStatement prep = con.prepareStatement(query);
            prep.setString(1, id);
            prep.executeUpdate();   //execute the update we made which is delete also delete the data in addbook
            JOptionPane.showMessageDialog(this, "Delete Succesfully");
            table.removeRow(row);   //perform the removerow, means it will be remove also on the jtable

        } catch (SQLException ex) {
            Logger.getLogger(adminMain.class.getName()).log(Level.SEVERE, null, ex);
        }


    }//GEN-LAST:event_deletehistoryActionPerformed

    private void studentlistActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentlistActionPerformed
        // TODO add your handling code here:
        cardR(liststudent);
        studentlist();


    }//GEN-LAST:event_studentlistActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        prepareConnection();

        DefaultTableModel table = (DefaultTableModel) stulist.getModel();
        prepareConnection();
        String studentID = "";
        int row = -1;
        int select = stulist.getSelectedRow();

        try {
            row = stulist.getSelectedRow();
            studentID = "" + stulist.getValueAt(row, 0);
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(this, "No Book Selected");
            return;
        } catch (ArrayIndexOutOfBoundsException ex) {
            JOptionPane.showMessageDialog(this, "No Book Selected");
            return;
        } catch (NoSuchMethodError ex) {
            JOptionPane.showMessageDialog(this, "No Book Selected");
            return;
            //we put return so the code will not continue to the next try catch witch is the next of this part be perfomed
        }

        try {

            String query = "DELETE FROM student WHERE studentID= ?";
            PreparedStatement prep = con.prepareStatement(query);
            prep.setString(1, studentID);
            prep.executeUpdate();   //execute the update we made which is delete also delete the data in addbook
            JOptionPane.showMessageDialog(this, "Delete Succesfully");
            table.removeRow(row);   //perform the removerow, means it will be remove also on the jtable

        } catch (SQLException ex) {
            Logger.getLogger(adminMain.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(adminMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(adminMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(adminMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(adminMain.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new adminMain().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Addbook;
    private javax.swing.JPanel Addstudent;
    private javax.swing.JPanel History;
    private javax.swing.JPanel Listallbooks;
    private javax.swing.JButton add;
    private javax.swing.JButton addbook;
    private javax.swing.JButton addstudent;
    private javax.swing.JTextField authorName;
    private javax.swing.JTextField bookID;
    private javax.swing.JTextField bookTitle;
    private javax.swing.JTable booklist;
    private javax.swing.JPanel borrowedBook;
    private javax.swing.JComboBox<String> category;
    private javax.swing.JButton delete;
    private javax.swing.JButton deletehistory;
    private javax.swing.JButton history;
    private javax.swing.JLabel idlabel;
    private javax.swing.JTable issue;
    private javax.swing.JButton issuedbook;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JButton listallbooks;
    private javax.swing.JPanel liststudent;
    private javax.swing.JButton logout;
    private javax.swing.JPanel panelCard;
    private javax.swing.JTextField quantity;
    private javax.swing.JTable return1;
    private javax.swing.JButton save;
    private javax.swing.JTextField studentid;
    private javax.swing.JButton studentlist;
    private javax.swing.JTextField studentname;
    private javax.swing.JTable stulist;
    private javax.swing.JTextField upauthor;
    private javax.swing.JTextField upbookid;
    private javax.swing.JTextField upbooktitle;
    private javax.swing.JComboBox<String> upcategory;
    private javax.swing.JButton update;
    private javax.swing.JTextField upquantity;
    // End of variables declaration//GEN-END:variables

}
